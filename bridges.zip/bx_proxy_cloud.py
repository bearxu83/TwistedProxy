#for web server
server_siyao = '\x00\x0c\xbd\x19::\x12f\xe5\xb7\xad\xe7\xea\x9a\x10\x13\n\x88NT\xc7\xfb\xa9\xde[\xafw0\xa1\x1fd\xef'
#for web server and proxy server
server_duichen_yaoshi = 'I\xa9u\xc0\x9e8\x8d\xe1\xf3\xb5\xfby\x04\xb6=|\xf9uh\x8b\xeanS|\xb1\x1aS&LX*X'


#token {"session_yaoshi", "exipre"}
fake_config = {
    "Status": True,
    "ip_list":{"us": ["127.0.0.1:443"]},
    "token": '''\x0f\x1e\xc8\xd7$\x98\xd7\xcc'm\xa49\xd8\x1c\n\x94eC\x05N\x82\xb7\x8b!\x8c\t\x97\x10\xe7\xbb\x0c\x9dF\x80\xc9\xee\xe8\x9c\x94\x08E\xf4zz\xfc\xb0\xd0j\x8c^\x13c\xb4\x92\xca\x81\xe1\xb6\x00\x16\xe6\xd4\xd5\x8e[A\xe5\x88\x98\xfc=mC9N\xba\xfd\x17\x90\\\x02\x14\xa3L\xdb:=\x83\x17=\xca\xc9\x16\xaa\xffB\xa8\xd2hO-3\xf1\x0ch\x951\xdfT\x9f\x9c\xb9\xf6x\xb5}\x15)\xa8\xab\xc7\x82n\xe8\xc3\x10\xe1\xbbP''',
    "session_yaoshi": '9I0lOboVP1ddP-u5vt1fV0OuTIMjpKqeXFsQSxXh_Ds='
    }
from bx_proxy_local import *

class CloudTransfer(TransferContract):
    server_duichen_yaoshi = server_duichen_yaoshi
    closed = 0
    has_header = False
    after_conn = None
    host = None

    # ~ def dataReceived(self, data):
    # ~ log.msg('len of data received', len(data))
    # ~ TransferContract.dataReceived(self, data)
    def __init__(self):
        if Config.need_encrypt and Config.is_key_in_server:
            self.crypt_tool = nacl.secret.SecretBox(bytes(Config.settings['session_yaoshi']), nacl.encoding.URLSafeBase64Encoder)
    def parse_data(self, data):
        # ~ log.msg('<-CT clean data:', repr(data))
        if (not self.crypt_tool) and Config.need_encrypt:
            among_server_box = nacl.secret.SecretBox(self.server_duichen_yaoshi)
            clear_token = json.loads(among_server_box.decrypt(data))
            self.crypt_tool = nacl.secret.SecretBox(nacl.encoding.URLSafeBase64Encoder.decode(bytes(clear_token['session_yaoshi'])))
        elif not self.has_header:
            self.header = json.loads(data)
            # ~ log.msg('<-CT monitor:', self.header)
            self.host = self.header['host']
            port = self.header['port']
            self.is_ssl = self.header['is_ssl']
            # ~ if is_ssl:
            # ~ self.fetcher_factory = SslFetcherFactory(self)
            # ~ else:
            # ~ self.fetcher_factory = HttpFetcherFactory(self)
            log.msg('|)ata CT HTTP info: ', self.header)
            self.client = endpoints.TCP4ClientEndpoint(reactor, self.host, port, timeout=30)
            self.hff = HttpFetcherFactory(self)
            self.after_conn = self.client.connect(self.hff)
            self.hff.on_conn = self.after_conn
            self.has_header = True
        else:
            # ~ log.msg('<-Cloud body data:', len(data))
            # ~ self.fetcher_factory.after_conn.addCallback(lambda child: (self.fetcher_factory.transfer(data), log.msg('cloud data sent', len(data))))
            self.after_conn.addCallback(self.proxy_data, data)

            self.after_conn.addErrback(self.fail_conn)
            # self.after_conn.addErrback(lambda reason: self.transport.loseConnection())
            # ~ self.after_conn.addErrback(lambda reason: log.msg('Can not connect', reason))
    @staticmethod
    def proxy_data(protocol, data):
        protocol.transport.write(data)
        return protocol

    def fail_conn(self, r):
        if not self.is_ssl:
            self.send_encrypted(
                "HTTP/1.1 504 Gateway Error(Timeout)\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
        self.transport.loseConnection()
    
    def handle_after_conn(self, p):
        p.transport.write(self.data)

    # ~ log.msg('->cloud data sent', len(data))

    def close(self):
        pass

    def connectionLost(self, reason):
        TransferContract.connectionLost(self, reason)
        # ~ log.msg('-->> Connection LOST', self.header, self._trans_state)
        # ~ log.msg('-->> Connection LOST', self._trans_state)
        if not reason.check(error.ConnectionDone):
            log.msg('-->> Connection LOST', reason, self.host)
        if self.after_conn:
            def close_after_conn(p):
                if p:
                    p.transport.abortConnection()
                    return p

            self.after_conn.addCallback(close_after_conn)
            self.after_conn = None
        self.closed = 1

class FCloudTransfer(CloudTransfer):
    useless_send_content = FRESPONSE
    discard_content = FHEAD

class CloudTransferFactory(protocol.ServerFactory):
    # ~ pool = TransferPool(CloudTransfer)
    protocol = CloudTransfer
    # ~ def buildProtocol(self, addr):
# ~ cloud_obj = self.pool.get()
# ~ cloud_obj.factory = self
# ~ return cloud_obj
class FCloudTransferFactory(CloudTransferFactory):
    # ~ pool = TransferPool(CloudTransfer)
    protocol = FCloudTransfer
    
class ServerStartManager(StartManager):
    filterObserver = FilteringLogObserver(textFileLogObserver(sys.stdout), (LogLevelFilterPredicate(LogLevel.error),))
    # ~ filterObserver = FilteringLogObserver(sys.stdout, (LogLevelFilterPredicate(LogLevel.error),))
    putsObserver = textFileLogObserver(sys.stdout)

    @classmethod
    def start_server(cls):
        global fake_config
        Config.settings = fake_config
        # ~ log.startLogging(open('d:/foo.log', 'w'))
        if len(sys.argv) > 1 and sys.argv[1] == 't':
            Config.settings = fake_config
            Config.settings['ip_list'] = {'us': ['127.0.0.1:%s' % CLOUD_PORT]}
            # ~ log.startLogging(DailyLogFile.fromFullPath("./transfer%s.log"%CLOUD_PORT))
            globalLogPublisher.addObserver(cls.putsObserver)
            reactor.listenTCP(CLOUD_PORT, FCloudTransferFactory())
            reactor.listenTCP(LOCAL_PORT, LocalServerFactory(FLocalTransferFactory))
            print('test env')
        elif len(sys.argv) > 1 and sys.argv[1] == 'c':
            Config.settings = fake_config
            #Config.settings['ip_list'] = {'us': ['88.80.189.44:%s' % CLOUD_PORT, '88.80.189.44:%s' % '8080']}
            #47.56.138.185:4433
            Config.settings['ip_list'] = {'us': ['47.241.64.152:8401']}
            globalLogPublisher.addObserver(cls.putsObserver)
            reactor.listenTCP(LOCAL_PORT, LocalServerFactory(LocalTransferFactory))
            print('Client test env')
        elif sys.platform in ('win32', 'darwin'):
            # ~ log.startLogging(DailyLogFile.fromFullPath("./transfer%s.log"%LOCAL_PORT))
            globalLogPublisher.addObserver(cls.putsObserver)
            reactor.addSystemEventTrigger("before", "shutdown",
                                          lambda: globalLogPublisher.removeObserver(cls.filterObserver))
            print('Windows env')
            ClientLogin().universal_login()
        elif sys.platform.startswith('linux'):
            port = int(sys.argv[1]) if len(sys.argv) > 1 else CLOUD_PORT
            # ~ log.startLogging(DailyLogFile.fromFullPath("./transfer%s.log"%port))
            daily_file_observer = textFileLogObserver(DailyLogFile.fromFullPath("./transfer%s.log" % port))
            globalLogPublisher.addObserver(cls.putsObserver)
            globalLogPublisher.addObserver(daily_file_observer)
            reactor.listenTCP(port, FCloudTransferFactory())
            print('linux env')
        reactor.run()

if __name__ == "__main__":
    ServerStartManager.start_server()
