#!/usr/bin/env python
# -*- coding: utf-8 -*-
# local sockets our of number in select(): malformed file descriptor found. Preening lists.
VERSION = 18101
COMPANY_NAME = '''
  _ ._   _   _ ._ o  _  |_ _|_  _  ._ 
 _> |_) (/_ (_ |  | (_| | | |_ (/_ |  
    |                _|               
'''
import sys

# ~ OLD_EXECPTHOOD = sys.excepthook
# ~ sys.excepthook = lambda *i: None
# pyinstaller put the reactor into sys.modules before running, hack to run the reactor without problem
sys.modules.pop('twisted.internet.reactor', None)
from twisted.logger import globalLogBeginner, textFileLogObserver, FilteringLogObserver, globalLogPublisher, \
    InvalidLogLevelError, \
    Logger, LogLevel, LogLevelFilterPredicate

log = Logger('SpecRighter')
from twisted.python import log as old_log

log.msg = old_log.msg
log.err = old_log.err
log.err = lambda f: log.failure(None, f, LogLevel.debug)
if sys.platform == 'win32':
    import win32inetcon as wininetcon
    import win32api
    from patch_abstract import win_proxy_change, INTERNET_PER_CONN_FLAGS_UI
    from patch_abstract import patch_FileHandle

    patch_FileHandle()
    # ~ from twisted.internet.iocpreactor.abstract import FileHandle


    # ~ FileHandle.allow_to_create_iocp_event = True

    # ~ def patch_cbWrite(self, rc, numBytesWritten, evt):
    # ~ #if rc <> 0:
    # ~ #    print ('<->>', rc, numBytesWritten)
    # ~ if self._handleWrite(rc, numBytesWritten, evt):
    # ~ self.doWrite()
    # ~ else:
    # ~ self.allow_to_create_iocp_event = True

    # ~ def patch_resumeWriting(self):
    # ~ self._writeScheduled = None
    # ~ if self.allow_to_create_iocp_event:
    # ~ self.allow_to_create_iocp_event = False
    # ~ self.doWrite()
    # ~ FileHandle._cbWrite = patch_cbWrite
    # ~ FileHandle._resumeWriting = patch_resumeWriting
    from twisted.internet import iocpreactor

    iocpreactor.install()

from twisted.internet import reactor, protocol, defer, endpoints, error
# ~ print reactor
from twisted.protocols.policies import TimeoutMixin
from twisted.protocols.basic import FileSender
from twisted.web.http import HTTPFactory, HTTPChannel, Request

from twisted.python.logfile import DailyLogFile
#import treq

from uuid import getnode as get_mac
import getpass
import time
import urlparse
import random
import json
import struct
import warnings
import nacl.secret, nacl.encoding, nacl.public
DKEY = 'YKgD93VKGwsQuQXj244ypa_sXDcRMNE5_lX-WsoAT-0='

LKEY = 'zuuWMbJRGPJb109AcY-T2AGQxKp4VSOnXnskCUsiX0E='

webserver_public_key = '''\xb1\xa1?\x9a\\\xe3\xd0~)QoT\xcd\xca\xb6\xa4&D\xde2\xa7\xedX\xd0V\x00\x88\x1e\xf9\x07\xc1q'''
#~ AUTH_SERVER = 'http://192.168.0.10:8000/onlinestore/default'
AUTH_SERVER = 'http://35.197.10.227:8000/onlinestore/default'

LOCAL_VERSION = 18101
LOCAL_CHOSEN_REGION = 'us'
CLOUD_PORT = 8309
LOCAL_PORT = 8091
TP_INIT_CONN = 12
TP_RETRY_INTERVAL = 0.6
NEED_ENCRYPTED = True
VERIFY_SIZE = 0
PACKETSIZE_INDICATOR = 4

FHEAD = '''
GET /remotelearning HTTP/1.1
Host: remotelearning.harvard.edu
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
'''
FRESPONSE = '''
HTTP/1.1 301 Moved Permanently
Location: https://www.harvard.edu
'''
class Config(object):
    settings = {}
    is_key_in_server = True
    need_encrypt = NEED_ENCRYPTED


class Fetcher(protocol.Protocol):
    def __init__(self, father):
        self.father = father

    def send_data(self, value):
        # ~ log.msg('Fetcher sent data')
        self.transport.write(value)

    # ~ print 'value sent'

    # ~ def connectionLost(self, reason):
    # ~ if self.father.is_ssl:
    # ~ self.father.transport.loseConnection()

    def dataReceived(self, value):
        # ~ log.msg('<-Outest', len(value))
        self.father.write(value)

    # ~ print 'send back'


class FetcherFactory(protocol.ClientFactory):
    protocol = Fetcher

    def __init__(self, server):
        self.server = server
        self.after_conn = defer.Deferred()
        self.after_lost = defer.Deferred()

    def buildProtocol(self, addr):
        self.child = self.protocol(self.server, self)
        return self.child

    def transfer(self, data):
        self.child.transport.write(data)

    # ~ log.msg('++Data:', len(data))

    # ~ def clientConnectionFailed(self, connector, reason):
    # ~ self.server.transport.loseConnection()
    # ~ self.server.handle_close(source='here')


def split_path(hostport):
    host, port = hostport.split(':')
    return host, int(port)


class TransferContract(protocol.Protocol, TimeoutMixin):
    SIZE_STATE = 0
    BODY_STATE = 1
    DISCARD_STATE = 2
    # ~ MAIN_STATE = 3
    # ~ DECRYPT_STATE = 4
    crypt_tool = None

    def connectionMade(self):
        self.body_size = 0
        self.verify_tag = ''
        self.here_closed = False
        self.remote_closed = False
        self.has_header = False
        self._trans_buff = ''  # bytearray()
        self._trans_state = self.SIZE_STATE
        self.transport.setTcpNoDelay(True)
        # ~ self.transport.setTcpKeepAlive(True)
        self.transport.readBufferSize = PACKETSIZE_INDICATOR + 4096
        self.setTimeout(1900)

    def dataReceived(self, data):
        # ~ log.msg('raw data recved', data)
        self.setTimeout(330)

        self._trans_buff += data
        if (self._trans_state == self.SIZE_STATE) and (len(self._trans_buff) >= PACKETSIZE_INDICATOR):
            # ~ self.setTimeout(330)
            self.got_size_data(self._trans_buff[:PACKETSIZE_INDICATOR])
        elif (self._trans_state == self.BODY_STATE) and (len(self._trans_buff) >= (PACKETSIZE_INDICATOR + self.body_size)):
            result_data, self._trans_buff = self._trans_buff[PACKETSIZE_INDICATOR:self.body_size+PACKETSIZE_INDICATOR], self._trans_buff[PACKETSIZE_INDICATOR+self.body_size:]
            self.got_unchecked_body_data(result_data)
        elif self._trans_state == self.DISCARD_STATE:
            self.got_discard_data()
        # ~ log.msg('<<<<<<<<Before Discard State:', self._trans_state)
        # ~ d = self.read_bytes(self.body_size)
        # ~ d.addCallback(lambda ig: self.handle_close(source='remote'))
        # ~ d.addCallback(lambda ignore: self.set_status(self.SIZE_STATE))
        # ~ d.addErrback(self.after_error)
    def got_discard_data():
        pass
        
    def timeoutConnection(self):
        log.msg('>>>>>>>>>>Current State:' + str(self._trans_state), self)
        self.transport.loseConnection()
        log.msg('[X] TimeOut: long time no data recved')

    def connectionLost(self, reason):
        self.setTimeout(None)

    def after_error(self, reason):
        log.msg('>>>>>>>>>>Current State:' + str(self._trans_state))
        self.transport.abortConnection()
        log.msg('[X]', reason)

    def got_size_data(self, size_bytes):
        # ~ self.verify_tag, encrypted_bytes = data[:VERIFY_SIZE], data[VERIFY_SIZE:]
        #size_bytes = self.decrypt(data)
        (self.body_size, ) = struct.unpack('i', size_bytes)
        # ~ log.msg('<->body', self.body_size)
        # ~ log.msg('here closed', self.here_closed)

        # before cloud2:bug below, after reboot, cloud get header ,get body and no action continue
        if self.body_size > 0 and not self.here_closed:
            # ~ if self.body_size > 0:
            self.set_status(self.BODY_STATE)
        elif self.body_size < 0:
            raise ValueError('Body size can not below 0')
            # ~ self.body_size = 0 - self.body_size
            # ~ self.set_status(self.DISCARD_STATE)
        else:
            raise ValueError('Body size can not equal 0')
            # ~ self.set_status(self.DISCARD_STATE)

    def got_unchecked_body_data(self, data):
        if self.crypt_tool:
            comfortable_data = self.decrypt(data)
        else:
            comfortable_data = data
        if self.verify_body_data(comfortable_data):
            self.parse_data(comfortable_data)
            self.set_status(self.SIZE_STATE)
        else:
            self.verify_failed(comfortable_data)

    def parse_data(self, data):
        # to change has_header
        raise NotImplementedError()

    def verify_body_data(self, data):
        return True

    def verify_failed(self, data):
        pass

    def after_header_data_old(self, result):
        self.header = json.loads(result)
        if self.header_size > 100:
            log.msg('just after size', self.header)
        log.msg('just after header', self.header)
        self.parse_header()
        if self.header['encrypted_size'] == 0:
            self.set_status(self.MAIN_STATE)
        else:
            self.decrypted_size = self.header['encrypted_size']
            self.set_status(self.DECRYPT_STATE)

    def set_status(self, next_state):
        # ~ log.msg('*****>> Before Status:', self._trans_state)
        self._trans_state = next_state
        # ~ log.msg('*****>> After Status:', self._trans_state)
        # ~ log.msg('_trans_buff size', len(self._trans_buff))
        min_bytes_length = PACKETSIZE_INDICATOR
        if next_state == self.BODY_STATE:
            min_bytes_length += self.body_size
        if len(self._trans_buff) >= min_bytes_length:
            self.dataReceived('')

    def send_encrypted_old(self, header, need_encrypted_data, contents):
        encrypted_data = self.encrypt(need_encrypted_data)
        header['encrypted_size'] = len(encrypted_data)
        # ~ log.msg('sent header size:', len(encrypted_data))
        trans_header = json.dumps(header)
        self.transport.write(struct.pack('I', len(trans_header)))
        self.transport.write(trans_header)
        self.transport.write(encrypted_data)
        self.transport.write(contents)

        # ~ def send(self, data):

    # ~ self.send_encrypted(data)
    # ~ log.msg('cloud send back data')

    def decrypt(self, part_data):
        # ~ data = self.crypt_tool.decrypt('gAAAAABWH' + part_data)
        if NEED_ENCRYPTED:
            return self.crypt_tool.decrypt(part_data)
        else:
            return part_data

    def encrypt(self, data):
        if NEED_ENCRYPTED:
            return self.crypt_tool.encrypt(data)
        else:
            return data

    def transfer(self, data):
        raise NotImplementedError()

    def handle_close(self, source):
        pass

    def handle_close_old(self, source):
        if source == 'here' and (not self.here_closed):
            self.here_closed = True
            self.send_close_bytes('cancel')
        elif source == 'remote' and (not self.remote_closed):
            self.remote_closed = True
        if self.here_closed and self.remote_closed:
            # ~ self.update()
            # ~ self.factory.pool.put(self.factory)
            self.handle_both_close()
        elif not self.here_closed:
            # ~ self.send_close_bytes('cancel')
            self.handle_remote_close()
        # ~ elif not self.remote_closed:
        # ~ self.send_close_bytes('cancel')

    def send_encrypted(self, bytes_data, meaning=1):
        self.resetTimeout()
        if bytes_data:
            encrypted_data = self.encrypt(bytes_data)
            self.transport.writeSequence(
                (struct.pack('i', len(encrypted_data) * meaning), encrypted_data))

    def send_uncrypted(self, bytes_data):
        self.resetTimeout()
        if bytes_data:
            self.transport.writeSequence((struct.pack('i', len(bytes_data)), bytes_data))

    def write(self, data):
        self.resetTimeout()
        self.send_encrypted(data)

    def registerProducer(self, producer, streaming):
        self.transport.registerProducer(producer, streaming)

    def unregisterProducer(self):
        self.transport.unregisterProducer()

    def send_close_bytes(self, bytes_data):
        # It's a bug that here don't use send_encrypt
        # ~ self.transport.write(struct.pack('i', len(bytes_data) * -1))
        # ~ self.transport.write(bytes_data)
        self.send_encrypted(bytes_data, meaning=-1)

    def handle_remote_close(self):
        raise NotImplementedError()

    def handle_both_close(self):
        raise NotImplementedError()
        
class FTransferContract(TransferContract):
    def connectionMade(self):
        TransferContract.connectionMade(self)
        self._trans_state = self.DISCARD_STATE
        self.transport.write(self.useless_send_content)
        
    def got_discard_data(self):
        if len(self._trans_buff) >= len(self.discard_content):
            self._trans_buff = self._trans_buff[len(self.discard_content):]
            self.set_status(self.SIZE_STATE)
        
    def dataReceived(self, value):
        try:
            TransferContract.dataReceived(self, value)
        except Exception as e:
            log.info("!!! Core Error, %s"%(e))

class TransferPool(object):
    def __init__(self, factory_class):
        self.factory_class = factory_class
        self.local_transfer_endpoints = []
        for ip_addr in Config.settings['ip_list'][LOCAL_CHOSEN_REGION]:
            self.local_transfer_endpoints.append(endpoints.clientFromString(reactor, "tcp:%s:timeout=30" % ip_addr))
            log.info("tcp:%s:timeout=30" % ip_addr)
        self._pool = []
        self.open_connections(TP_INIT_CONN)

    def get(self, *args, **kargs):
        if len(self._pool) < 1:
            self.open_connections(2)
        elif len(self._pool) < 20:
            self.open_connections(1)
        new_one = self._pool.pop(0)
        new_one.on_connection.addCallback(lambda p: (p, p.setTimeout(330))[0] if p else None)
        return new_one.on_connection
        
    @staticmethod
    def after_conn(p, factory):
        log.msg('LT connected', p)
        factory.on_lost.callbacks = []
        factory.on_lost.errbacks = []
        return p

    def open_connections(self, num_to_open):
        for i in range(num_to_open):
            local_trans_factory = self.factory_class()
            local_after_conn = random.choice(self.local_transfer_endpoints).connect(local_trans_factory)
            local_trans_factory.on_connection = local_after_conn

            def succ_lost(_, factory):
                log.msg("~~~~~~~~local pool remove lost after_conn")
                try:
                    self._pool.remove(factory)
                    log.msg("Removed")
                except ValueError:
                    pass

            local_trans_factory.on_lost.addCallback(succ_lost, local_trans_factory)
            local_trans_factory.on_lost.addErrback(lambda f: f.trap(defer.CancelledError, error.ConnectionLost))
            local_after_conn.addCallback(self.after_conn, local_trans_factory)
            local_after_conn.addErrback(lambda e: log.error(str(e.value)))
            self._pool.append(local_trans_factory)
        # ~ log.msg('----------------------got a pool', self._pool)
        

    def put(self, factory_obj):
        if len(self._pool) > -1:
            # ~ factory_obj.close()
            pass
        elif not factory_obj.after_lost.called:
            factory_obj.num_cached += 1
            log.msg('Num_Cached: ', factory_obj.num_cached)
            self._pool.append(factory_obj)

    def naive_clear(self, dead_transfer):
        try:
            for t in self._pool:
                t.close()
        except:
            log.msg('t.close() wrong')
        self._pool = []
        try:
            dead_transfer.factory.father.finish()
        except (RuntimeError, AttributeError, error.ConnectionDone):
            pass

    def clear(self):
        self._pool = []


class LocalTransfer(TransferContract):
    def __init__(self):
        if NEED_ENCRYPTED:
            self.crypt_tool = nacl.secret.SecretBox(bytes(Config.settings['session_yaoshi']), nacl.encoding.URLSafeBase64Encoder)
        self.is_existed = 0
        self.existed_hosts = []

        self.test_size = 0

    def connectionMade(self):
        TransferContract.connectionMade(self)
        if NEED_ENCRYPTED and (not Config.is_key_in_server):
            self.send_uncrypted(Config.settings['token'])

    def initialize(self, factory_father, py_header, html_header, content):
        factory_father.transport.unregisterProducer()
        factory_father.transport.registerProducer(self.transport, streaming=True)
        self.factory.father = factory_father
        py_header['lt_ip'] = self.transport.getHost().host
        self.py_header = py_header
        self.html_header = html_header
        self.content = content
        self.heartbeat_d = None
        # ~ log.msg('debug packet:', repr(self.html_header))
        if not self.is_existed:
            self.send_encrypted(json.dumps(py_header))
        if html_header:
            self.send_encrypted(html_header)
        # if ssl mode, d will callback at once and do nothing
        d = FileSender().beginFileTransfer(content, self)
        d.addCallback(lambda _: factory_father.finish())
        self.is_existed += 1
        self.existed_hosts.append(py_header['host'])
        return self

    def parse_data(self, data):
        # ~ log.msg(len(data))
        self.factory.father.write(data)

    def handle_remote_close(self):
        log.msg('Local: handle remote close, close local')
        if not self.factory.father.finished:
            try:
                self.factory.father.finish()
            except RuntimeError:
                pass

    def connectionLost(self, reason):
        TransferContract.connectionLost(self, reason)
        self.unregisterProducer()
        log.msg('->Local End:', self.existed_hosts)
        # ~ log.msg('->Local End Reason:', reason)
        self.factory.on_lost.callback(None)
        if self.factory.father:
            _ = None
            self.factory.father.transport.unregisterProducer()
        if (self.is_existed > 0) and self.factory.father:
            log.msg('-> close father', self.is_existed)
            self.factory.father.transport.loseConnection()
            self.factory.father = None
        self.is_existed = 0

    # ~ if self.factory.father and (not self.factory.father.finished):
    # ~ try:
    # ~ self.factory.father.finish()
    # ~ except RuntimeError:
    # ~ pass
    # ~ self.factory.father.channel2.transport.loseConnection()
    # ~ self.factory = None
    # ~ self.factory.father = None
    # ~ self.factory.father.finish()

class FLocalTransfer(LocalTransfer):
    useless_send_content = FHEAD
    discard_content = FRESPONSE

class LocalTransferFactory(protocol.ClientFactory):
    protocol = LocalTransfer

    def __init__(self):
        self.father = None
        self.on_lost = defer.Deferred()

    def update(self, father, py_header, html_header, contents):
        log.msg('before sending info:', self.father)
        self.father = father
        self.py_header = py_header
        self.html_header = html_header
        self.contents = contents
        self.child.py_header = py_header
        self.child.html_header = html_header
        self.child.contents = contents
        # ~ can't define self.child.body_size = 0 for conflict with DISCARD_STATE
        # log.msg('value of State', self.child._trans_state)
        # ~ self.child.send_encrypted(self.py_header, self.html_header, self.contents)
        # log.msg('updated sending info:', self.html_header)
        self.child.verify_tag = ''
        self.child.here_closed = False
        self.child.remote_closed = False
        self.child.send_encrypted(json.dumps(self.py_header))
        self.child.send_encrypted(self.html_header)
        self.child.send_encrypted(contents)
        heartbeat_d = defer.Deferred()
        heartbeat_d.addCallback(
            lambda ig: log.msg("===================From My Eye, remote is end====================="))
        # reactor.callLater(3, heartbeat_d.callback, None)
        self.child.heartbeat_d = heartbeat_d
        return self

    def close(self):
        try:
            self.child.transport.loseConnection()
        except error.ConnectionDone:
            pass
        self.father = None

        # ~ def buildProtocol(self, addr):

    # ~ #self.child = LocalTransfer(self, self.py_header, self.html_header, self.contents)
    # ~ self.child = LocalTransfer(self)
    # ~ return self.child

    # ~ def clientConnectionLost(self, c, reason):
    # ~ self.on_lost.callback(reason)
    # ~ log.msg('-> Connection Fail')
    # ~ try:
    # ~ self.father.finish()
    # ~ except RuntimeError:
    # ~ pass

    def startedConnecting(self, x):
        pass

class FLocalTransferFactory(LocalTransferFactory):
    protocol = FLocalTransfer
    
class ProxyRequest2(Request):
    _retry_times = 0
    mac_addr = get_mac()

    def process(self):
        # ~ self.channel._networkProducer.unregisterProducer()
        is_ssl = self.method == 'CONNECT'
        if is_ssl:
            host, port = self.uri.split(':')
        else:
            parsed = urlparse.urlparse(self.uri)
            protocol = parsed[0]
            host = parsed[1]
            port = 80
            if ':' in host:
                host, port = host.split(':')
                port = int(port)
            rest = urlparse.urlunparse(('', '') + parsed[2:])
            if not rest:
                rest = rest + '/'
        py_header = dict(host=host, port=int(port), is_ssl=is_ssl, client_ip=self.transport.getPeer().host,
                         mac=self.mac_addr)
        # ~ self.content.seek(0, 0)
        log.msg('get the request', py_header['host'])
        self.local_connected = self.channel.local_after_conn
        host_changed = self.channel.host and (self.channel.host != py_header['host'])
        if host_changed:
            log.msg('-------------------------------------------------------------------')
            log.msg('old header:', self.channel.host, '  new header:', py_header['host'])
        self.channel.host = py_header['host']
        if (not self.local_connected) or host_changed:
            old_conn = self.local_connected
            self.local_connected = self.channel.get_local_after_conn()
            if not self.local_connected:
                if self._retry_times < 3:
                    self._retry_times += 1
                    log.msg('reactor will retry in seconds')
                    defer_local_transfer = reactor.callLater(TP_RETRY_INTERVAL * self._retry_times, self.process)
                else:
                    self.transport.write(
                        "HTTP/1.1 504 Network Failed or Proxy Service Down\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
                    self.finish()
                return

            # ~ if host_changed:
            # ~ log.msg('---------------------------------')
            # ~ log.msg('switch to the new local transfer')
            # ~ old_conn.addCallback(lambda p: (p.factory.on_lost.addCallback(lambda _: [log.msg('>> on_lost called'), self.process()]), p, log.msg('change host redo process', p.factory.on_lost.callbacks))[1])
            # ~ return

        # ~ self.local_connected.addErrback(lambda e, fail_conn, transport: (log.msg('should be ok'), fail_conn.cancel(), transport.loseConnection()), self.local_connected, self.transport)
        if is_ssl:
            # ~ log.msg('write back')
            # ~ log.msg('Channel data buffer: ', self.channel._dataBuffer)
            self.transport.write("HTTP/1.1 200 OK\r\n\r\n")
            self.channel.is_ssl_mode = True
            self.local_connected.addCallback(lambda p: p.initialize(self, py_header, '', None) if p else None)
            # ~ self.channel.local_transfer_factories.append(self.local_factory)

            # ~ self.local_factory = LocalTransferFactory(self, py_header, '', '')
        else:
            # ~ log.msg('debug temp content:', temp_content)
            # ~ self.channel.local_after_conn.addCallback(lambda p: p.transport.loseConnection())
            headers_dict = self.getAllHeaders().copy()
            # headers_dict.pop('keep-alive', None)
            headers_dict["connection"] = headers_dict.pop('proxy-connection', 'keep-alive')
            if 'host' not in headers_dict:
                headers_dict['host'] = host
            headers = ["%s: %s\r\n" % (k.capitalize(), v) for k, v in headers_dict.items()]
            headers.insert(0, "%s %s %s\r\n" % (self.method, rest, self.clientproto))
            headers.append("\r\n")
            html_header = ''.join(headers)
            self.local_connected.addCallback(lambda p: p.initialize(self, py_header, html_header, self.content))
        # ~ self.local_connected.addBoth(lambda p: (self.finish(), p)[1])
        # ~ self.channel.local_transfer_factories.append(self.local_factory)
        # ~ self.local_factory = LocalTransferFactory(self, py_header, html_header, self.content.read())
        # ~ reactor.connectTCP(CLOUD_HOST, CLOUD_PORT, self.local_factory)
        # self.channel2 = self.channel
        # ~ test_d = self.notifyFinish()
        # ~ test_d.addCallback(lambda ig: self.channel2.transport.loseConnection() if len(self.channel2.requests) == 0 else None)
        # self.finish()
        # ~ def after_finish(ig):
        # ~ if not self.local_factory.after_lost.called:
        # ~ self.local_factory.after_conn.addCallback(lambda ig: self.local_factory.child.handle_close(source='here'))
        # ~ test_d.addCallback(after_finish)

    @staticmethod
    def clean_old_local_transfer(protocol):
        protocol.is_existed = 0
        protocol.transport.loseConnection()
        return protocol

    def write(self, data):
        # ~ log.msg('<-father wrote back', repr(data))
        self.transport.write(data)

    def finish(self):
        log.msg('finished: ', self.channel.host)
        if self.channel.is_ssl_mode:
            self.local_connected.addCallback(lambda p: (p, p.registerProducer(self.channel, streaming=True))[0])
            self.channel._networkProducer.resumeProducing()
            return
        if self._disconnected:
            raise RuntimeError(
                "Request.finish called on a request after its connection was lost; "
                "use Request.notifyFinish to keep track of this.")
        if self.finished:
            warnings.warn("Warning! request.finish called twice.", stacklevel=2)
            return

        # ~ if self.chunked:
        # write last chunk and closing CRLF
        # ~ self.transport.write(b"0\r\n\r\n")

        # log request
        # ~ if hasattr(self.channel, "factory"):
        # ~ log.msg('log self')
        # ~ self.channel.factory.log(self)

        # ~ if hasattr(self.channel, 'is_ssl_mode') and self.channel.is_ssl_mode:
        # ~ self.channel.transport.loseConnection()
        # ~ return

        self.finished = 1
        if not self.queued:
            self._cleanup()


class LocalServer(HTTPChannel):
    requestFactory = ProxyRequest2
    is_ssl_mode = False

    def get_local_after_conn(self):
        #Sometimes firefox will send different website to one channel
        if self.local_after_conn:
            def lose_conn(p):
                p.is_existed = 0
                p.factory.father = None
                p.transport.loseConnection()
                return p

            self.local_after_conn.addCallback(lose_conn)
        self.local_after_conn = self.factory.pool.get()
        return self.local_after_conn

    def connectionMade(self):
        self.host = None
        self.disconnected = False
        self.local_after_conn = None
        HTTPChannel.connectionMade(self)

    # ~ self.transport.setTcpNoDelay(True)
    # ~ self.transport.setTcpKeepAlive(True)
    # ~ self.transport.writeBufferSize =  256
    # ~ self.transport.bufferSize = 2 * 1024
    def dataReceived(self, data):
        # ~ log.msg('local server recved', len(self.requests), '------>', data)
        if self.is_ssl_mode and self.local_after_conn:
            # ~ log.msg('local server sent in ssl mode: ', len(data))
            def proxy_data(protocol, data):
                protocol.send_encrypted(data)
                return protocol

            self.local_after_conn.addCallback(proxy_data, data)
            # ~ self.requests[-1].local_factory.after_conn.addErrback(lambda reason: log.err(reason))
            return
        else:
            HTTPChannel.dataReceived(self, data)

    def connectionLost(self, reason):
        log.msg('-> LocalServer Lost', self.host, reason)
        self.disconnected = True
        if self.local_after_conn:
            def close_local_after_conn(p):
                if p:
                    p.transport.loseConnection()

            self.local_after_conn.addCallback(close_local_after_conn)
            self.local_after_conn = None

        if not self.is_ssl_mode:
            HTTPChannel.connectionLost(self, reason)

            # ~ def connectionLost(self, reason):
        # ~ if self.is_ssl_mode and self.requests:
        # ~ log.msg('local lost', self.requests[-1].local_factory.py_header)
        # ~ try:
        # ~ self.requests[-1].local_factory.after_conn.addCallback(lambda local: self.requests[-1].local_factory.child.handle_close(source='here'))
        # ~ #reactor.callLater(0, self.factory.pool.put, self.requests[-1].local_factory)
        # ~ except AttributeError:
        # ~ log.msg('local lost WRONG')
        # ~ else:
        # ~ HTTPChannel.connectionLost(self, reason)


class LocalServerFactory(HTTPFactory):
    protocol = LocalServer

    def __init__(self, ClientFactoryCls):
        self.pool = TransferPool(ClientFactoryCls)
        HTTPFactory.__init__(self)




class HttpFetcher(Fetcher):
    def connectionMade(self):
        self.transport.setTcpNoDelay(True)
        # ~ log.msg('Unified Http Fetcher created')
        # finish modify send
        self.father.registerProducer(self.transport, streaming=True)
        self.transport.registerProducer(self.father.transport, streaming=True)
        Fetcher.connectionMade(self)

    def connectionLost(self, reason):
        # ~ log.msg('Unified Http Fetcher lost')
        self.transport.unregisterProducer()
        if self.father:
            self.father.transport.unregisterProducer()
            self.father.transport.loseConnection()
            self.father.handle_close(source='here')
            self.father = None


class HttpFetcherFactory(protocol.ClientFactory):
    protocol = HttpFetcher

    def __init__(self, server):
        self.server = server
        self.noisy = False

    def buildProtocol(self, addr):
        self.child = self.protocol(self.server)
        self.child.factory = self
        return self.child


class ClientLogin(object):
    def __init__(self):
        self.local_server = None
        self.chosen_region = None
        self.subscribe_url = None
        self.check_interval = None
        local_private_key = nacl.public.PrivateKey.generate()
        self.local_public_key = local_private_key.public_key
        self.box = nacl.public.Box(local_private_key, settings.webserver_public_key)
        self.mistake_retry_count = 0
        self.win_old_proxy_server = None
        self.old_override = "localhost;127.*;10.*;172.16.*;172.17.*;172.18.*;172.19.*;172.20.*;172.21.*;172.22.*;172.23.*;172.24.*;172.25.*;172.26.*;172.27.*;172.28.*;172.29.*;172.30.*;172.31.*;172.32.*;192.168.*"

    def universal_login(self):
        global TP_INIT_CONN, TP_RETRY_INTERVAL
        user_info = raw_input('User Name or Login Code: ')
        if '@' in user_info:
            user_name = user_info
            user_pwd = getpass.getpass('Password(Your password is hidden while inputing): ')
            info = self.box.encrypt(
                json.dumps(dict(un=user_name, up=user_pwd, v=VERSION, mac=get_mac(), ct=time.ctime(), session_yaoshi=Config.settings['session_yaoshi'])))
            self.subscribe_url = '%s/public_call/run/get_auth/%s' % (AUTH_SERVER, info)
            self.check_interval = 900
            TP_INIT_CONN = 9
            TP_RETRY_INTERVAL = 0.6
        else:
            user_pass = user_info
            info = self.box.encrypt(json.dumps(dict(code=user_pass.upper(), v=VERSION, mac=get_mac(), ct=time.ctime(), session_yaoshi=CONFIG['session_yaoshi'])))
            self.subscribe_url = '%s/public_call/json/freelog/%s' % (AUTH_SERVER, info)
            self.check_interval = 1800
            TP_INIT_CONN = 8
            TP_RETRY_INTERVAL = 0.9
        # ~ print self.subscribe_url
        self.login()

    def login(self):
        d = treq.get(self.subscribe_url)

        def get_fail(e):
            log.err(e)
            log.error('NetworkError: Please check the network status or go to our website to get updates')
            if reactor.running:
                reactor.stop()
            self.recover_win_proxy(None)

        def get_json(json_content):
            global LOCAL_CHOSEN_REGION
            log.info("json_content: {json_content!r}", json_content=json_content)
            if json_content['Status'] == True:
                # refresh ip and other info
                Config.settings.update(json.loads(self.box.decrypt(bytes(json_content['config_dict']))))
                # ~ print CONFIG['ip_list']
                if not self.chosen_region:
                    if len(json_content['ip_list'].keys()) > 1:
                        regions = '/'.join(json_content['ip_list'].keys())
                        self.chosen_region = raw_input('Please select target area(%s): ' % regions).upper()
                    else:
                        self.chosen_region = json_content['ip_list'].keys()[0]
                LOCAL_CHOSEN_REGION = self.chosen_region
                if not self.local_server:
                    log.msg(json_content['Info'])
                    self.start_local_server()
                    self.set_win_proxy()
                    log.critical(json_content['Info'])
                    log.critical('Connected. Specrighter is working now.')
                reactor.callLater(self.check_interval, self.login)
            else:
                log.critical(json_content['Info'])
                self.mistake_retry_count += 1
                self.recover_win_proxy(None)
                if self.mistake_retry_count == 3:
                    log.error('You need to restart the software to retry.')
                    if reactor.running:
                        reactor.stop()
                else:
                    if self.local_server:
                        self.local_server.stopListening()
                        self.local_server = None
                    self.universal_login()

        # ~ d.addCallback(treq.collect, lambda r: log.msg(r))
        d.addCallback(lambda r: treq.json_content(r).addCallbacks(get_json, get_fail))
        d.addErrback(get_fail)

    def start_local_server(self):
        self.local_server = reactor.listenTCP(LOCAL_PORT, LocalServerFactory())

    def set_win_proxy(self):
        if sys.platform != 'win32':
            return
        exceptions = """
        *.cn
        http://*.*.*.*
        *.microsoft.com
        *.windowsupdate.com
        *.hao123.com
        *.aixifan.com
        *douban.fm
        *.126.net
        *.mi.com
        *.meizu.com
        *.iqiyi.com
        *.qiyi.com
        *.qiyipic.com
        *.le.com
        *.letv.com
        *.letvimg.com
        *.xunlei.com
        *.kankan.com
        *.kanimg.com
        *.tdimg.com
        *.tudou.com
        *.tudouui.com
        *.soku.com
        *.youku.com
        *.ykimg.com
        *.bilibili.com
        *.hdslb.com
        *.acgvideo.com
        *.ku6.com
        *.ku6cdn.com
        *.ku6img.com
        *.360buy.com
        *.360buyimg.com
        *.jd.com
        *.51buy.com
        *.icson.com
        *.dangdang.com
        *.yihaodian.com
        *.yihaodianimg.com
        *.paipai.com
        *.paipaiimg.com
        *.tmall.com
        *.taobao.com
        *.taobaocdn.com
        *.etao.com
        *.aicdn.com
        *.alicdn.com
        *.alimama.com
        *.alipay.com
        *.alipayobjects.com
        *.bankcomm.com
        *.bankofchina.com
        *.pingan.com
        *.citicbank.com
        *.eastmoney.com
        *.ali213.net
        *.cnbeta.com
        *.abchina.com
        *.ccb.com
        *.cmbchina.com
        *.douban.com
        *.doubanio.com
        *.weibo.com
        *.zhihu.com
        *.zhimg.com
        *.qq.com
        *.gtimg.com
        *.renren.com
        *.rrimg.com
        *.xiaonei.com
        *.xnpic.com
        *.dianping.com
        *.meituan.com
        *.dpfile.com
        *.huaban.com
        *.yupoo.com
        *.upyun.com
        *.upaiyun.com
        *.ifanr.com
        *.163.com
        *.netease.com
        *.eastday.com
        *.hexun.com
        *.sinaapp.com
        *.sohu.com
        *.solidot.org
        *.bing.com
        *.baidu.com
        *.bdstatic.com
        *.bdimg.com
        *.youdao.com
        *.sogou.com
        *.apple.com
        *.icloud.com
        *.macromedia.com
        *.qihucdn.com
        *.steampowered.com
    """
        exceptions = u';'.join(
            [exception.strip() for exception in exceptions.splitlines() if len(exception.strip()) > 0])
        exceptions = exceptions + ';' + self.old_override
        proxy_setting = {
            wininetcon.INTERNET_PER_CONN_PROXY_SERVER: "http=localhost:8091;https=localhost:8091",
            INTERNET_PER_CONN_FLAGS_UI: wininetcon.PROXY_TYPE_PROXY | wininetcon.PROXY_TYPE_DIRECT,
            wininetcon.INTERNET_PER_CONN_PROXY_BYPASS: exceptions,
        }
        # ~ proxy_setting = {
        # ~ wininetcon.INTERNET_PER_CONN_PROXY_BYPASS: exceptions,
        # ~ INTERNET_PER_CONN_FLAGS_UI: wininetcon.PROXY_TYPE_AUTO_PROXY_URL,
        # ~ wininetcon.INTERNET_PER_CONN_AUTOCONFIG_URL: "https://raw.githubusercontent.com/breakwa11/gfw_whitelist/master/whiteiplist.pac"
        # ~ }
        if not win_proxy_change(proxy_setting):
            raise Exception("Can not set up the proxy or the version of IE is too low")
        win32api.SetConsoleCtrlHandler(self.recover_win_proxy, True)

    # ~ import atexit
    # ~ atexit.register(self.recover_win_proxy, None)

    def recover_win_proxy(self, signal_type):
        if sys.platform != 'win32':
            return
        proxy_setting = {
            wininetcon.INTERNET_PER_CONN_FLAGS: wininetcon.PROXY_TYPE_DIRECT,
            wininetcon.INTERNET_PER_CONN_PROXY_BYPASS: self.old_override,
        }
        win_proxy_change(proxy_setting)


class StartManager(object):
    filterObserver = FilteringLogObserver(textFileLogObserver(sys.stdout), (LogLevelFilterPredicate(LogLevel.error),))
    # ~ filterObserver = FilteringLogObserver(sys.stdout, (LogLevelFilterPredicate(LogLevel.error),))
    putsObserver = textFileLogObserver(sys.stdout)

    @classmethod
    def start_client(cls):
        globalLogBeginner.beginLoggingTo([], True, False)
        globalLogPublisher.addObserver(cls.filterObserver)
        reactor.addSystemEventTrigger("before", "shutdown",
                                      lambda: globalLogPublisher.removeObserver(cls.filterObserver))
        print COMPANY_NAME
        print('Client Version: ', VERSION)
        ClientLogin().universal_login()
        reactor.run()


if __name__ == '__main__':
    StartManager.start_client()
    
